-------------------------------------------------------
Extension: msPNnotify for MODX Revolution 2.6.1-pl
-------------------------------------------------------
Version: 1.1.0-beta
Released: February 26, 2018
Since: February 26, 2018
Author: Pavel Zarubin