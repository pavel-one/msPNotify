<?php
/**
 * Default Russian Lexicon Entries for msPNnotify
 *
 * @package mspnnotify
 * @subpackage lexicon
 */
$_lang['mspnnotify'] = 'msPNnotify';