<?php
/**
 * Default English Lexicon Entries for msPNnotify
 *
 * @package mspnnotify
 * @subpackage lexicon
 */
$_lang['mspnnotify'] = 'msPNnotify';